
// change jasmines expect() to check so we can use expect.js asserstion library
var check = window.expect;